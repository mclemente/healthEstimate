Files in this folder are generated automatically and are thus hard to work with.
It's best to translate a source file instead: https://gitlab.com/tsuki.no.mai/healthestimate/-/blob/master/src/lang/en.yml

Thanks for considering contribution o/